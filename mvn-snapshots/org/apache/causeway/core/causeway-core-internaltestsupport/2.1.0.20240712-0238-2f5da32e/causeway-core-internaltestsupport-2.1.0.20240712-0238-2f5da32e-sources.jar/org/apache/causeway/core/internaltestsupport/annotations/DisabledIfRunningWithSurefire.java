/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.causeway.core.internaltestsupport.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.junit.jupiter.api.condition.DisabledIfSystemProperty;

/**
 * Works if combined with
 * <pre>{@code
 * <plugin>
 *      <groupId>org.apache.maven.plugins</groupId>
 *      <artifactId>maven-surefire-plugin</artifactId>
 *      ...
 *      <configuration>
 *          <systemPropertyVariables>
 *              <isRunningWithSurefire>true</isRunningWithSurefire>
 *          </systemPropertyVariables>
 *      </configuration>
 * </plugin>}
 * </pre>
 * @see DisabledIfSystemProperty
 * @apiNote This one is for framework internal use. 
 *      There is also a copy for the public API in the unittesting-applib module. 
 */
@Target({ ElementType.TYPE, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@DisabledIfSystemProperty(named = "isRunningWithSurefire", matches = "true")
public @interface DisabledIfRunningWithSurefire {

}
