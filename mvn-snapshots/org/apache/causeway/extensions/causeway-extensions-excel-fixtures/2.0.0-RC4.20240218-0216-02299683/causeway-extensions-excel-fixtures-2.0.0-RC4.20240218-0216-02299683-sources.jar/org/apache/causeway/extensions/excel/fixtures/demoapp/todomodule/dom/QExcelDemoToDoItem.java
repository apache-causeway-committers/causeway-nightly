package org.apache.causeway.extensions.excel.fixtures.demoapp.todomodule.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QExcelDemoToDoItem extends PersistableExpressionImpl<ExcelDemoToDoItem> implements PersistableExpression<ExcelDemoToDoItem>
{
    public static final QExcelDemoToDoItem jdoCandidate = candidate("this");

    public static QExcelDemoToDoItem candidate(String name)
    {
        return new QExcelDemoToDoItem(null, name, 5);
    }

    public static QExcelDemoToDoItem candidate()
    {
        return jdoCandidate;
    }

    public static QExcelDemoToDoItem parameter(String name)
    {
        return new QExcelDemoToDoItem(ExcelDemoToDoItem.class, name, ExpressionType.PARAMETER);
    }

    public static QExcelDemoToDoItem variable(String name)
    {
        return new QExcelDemoToDoItem(ExcelDemoToDoItem.class, name, ExpressionType.VARIABLE);
    }

    public final ObjectExpression<org.apache.causeway.applib.services.message.MessageService> messageService;
    public final ObjectExpression<org.apache.causeway.applib.services.repository.RepositoryService> repositoryService;
    public final ObjectExpression<org.apache.causeway.applib.services.title.TitleService> titleService;
    public final ObjectExpression<org.apache.causeway.extensions.excel.fixtures.demoapp.todomodule.dom.ExcelDemoToDoItemMenu> toDoItems;
    public final ObjectExpression<org.apache.causeway.applib.services.clock.ClockService> clockService;
    public final StringExpression description;
    public final LocalDateExpression dueBy;
    public final EnumExpression category;
    public final EnumExpression subcategory;
    public final StringExpression ownedBy;
    public final BooleanExpression complete;
    public final NumericExpression<java.math.BigDecimal> cost;
    public final NumericExpression<java.math.BigDecimal> previousCost;
    public final StringExpression notes;
    public final ObjectExpression<org.apache.causeway.applib.value.Blob> attachment;
    public final CollectionExpression dependencies;
    public final NumericExpression<Double> locationLatitude;
    public final NumericExpression<Double> locationLongitude;

    public QExcelDemoToDoItem(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.messageService = new ObjectExpressionImpl<org.apache.causeway.applib.services.message.MessageService>(this, "messageService");
        this.repositoryService = new ObjectExpressionImpl<org.apache.causeway.applib.services.repository.RepositoryService>(this, "repositoryService");
        this.titleService = new ObjectExpressionImpl<org.apache.causeway.applib.services.title.TitleService>(this, "titleService");
        this.toDoItems = new ObjectExpressionImpl<org.apache.causeway.extensions.excel.fixtures.demoapp.todomodule.dom.ExcelDemoToDoItemMenu>(this, "toDoItems");
        this.clockService = new ObjectExpressionImpl<org.apache.causeway.applib.services.clock.ClockService>(this, "clockService");
        this.description = new StringExpressionImpl(this, "description");
        this.dueBy = new LocalDateExpressionImpl(this, "dueBy");
        this.category = new EnumExpressionImpl(this, "category");
        this.subcategory = new EnumExpressionImpl(this, "subcategory");
        this.ownedBy = new StringExpressionImpl(this, "ownedBy");
        this.complete = new BooleanExpressionImpl(this, "complete");
        this.cost = new NumericExpressionImpl<java.math.BigDecimal>(this, "cost");
        this.previousCost = new NumericExpressionImpl<java.math.BigDecimal>(this, "previousCost");
        this.notes = new StringExpressionImpl(this, "notes");
        this.attachment = new ObjectExpressionImpl<org.apache.causeway.applib.value.Blob>(this, "attachment");
        this.dependencies = new CollectionExpressionImpl(this, "dependencies");
        this.locationLatitude = new NumericExpressionImpl<Double>(this, "locationLatitude");
        this.locationLongitude = new NumericExpressionImpl<Double>(this, "locationLongitude");
    }

    public QExcelDemoToDoItem(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.messageService = new ObjectExpressionImpl<org.apache.causeway.applib.services.message.MessageService>(this, "messageService");
        this.repositoryService = new ObjectExpressionImpl<org.apache.causeway.applib.services.repository.RepositoryService>(this, "repositoryService");
        this.titleService = new ObjectExpressionImpl<org.apache.causeway.applib.services.title.TitleService>(this, "titleService");
        this.toDoItems = new ObjectExpressionImpl<org.apache.causeway.extensions.excel.fixtures.demoapp.todomodule.dom.ExcelDemoToDoItemMenu>(this, "toDoItems");
        this.clockService = new ObjectExpressionImpl<org.apache.causeway.applib.services.clock.ClockService>(this, "clockService");
        this.description = new StringExpressionImpl(this, "description");
        this.dueBy = new LocalDateExpressionImpl(this, "dueBy");
        this.category = new EnumExpressionImpl(this, "category");
        this.subcategory = new EnumExpressionImpl(this, "subcategory");
        this.ownedBy = new StringExpressionImpl(this, "ownedBy");
        this.complete = new BooleanExpressionImpl(this, "complete");
        this.cost = new NumericExpressionImpl<java.math.BigDecimal>(this, "cost");
        this.previousCost = new NumericExpressionImpl<java.math.BigDecimal>(this, "previousCost");
        this.notes = new StringExpressionImpl(this, "notes");
        this.attachment = new ObjectExpressionImpl<org.apache.causeway.applib.value.Blob>(this, "attachment");
        this.dependencies = new CollectionExpressionImpl(this, "dependencies");
        this.locationLatitude = new NumericExpressionImpl<Double>(this, "locationLatitude");
        this.locationLongitude = new NumericExpressionImpl<Double>(this, "locationLongitude");
    }
}
