package org.apache.causeway.extensions.sessionlog.jdo.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QSessionLogEntry extends PersistableExpressionImpl<SessionLogEntry> implements PersistableExpression<SessionLogEntry>
{
    public static final QSessionLogEntry jdoCandidate = candidate("this");

    public static QSessionLogEntry candidate(String name)
    {
        return new QSessionLogEntry(null, name, 5);
    }

    public static QSessionLogEntry candidate()
    {
        return jdoCandidate;
    }

    public static QSessionLogEntry parameter(String name)
    {
        return new QSessionLogEntry(SessionLogEntry.class, name, ExpressionType.PARAMETER);
    }

    public static QSessionLogEntry variable(String name)
    {
        return new QSessionLogEntry(SessionLogEntry.class, name, ExpressionType.VARIABLE);
    }

    public final ObjectExpression<java.util.UUID> sessionGuid;
    public final StringExpression httpSessionId;
    public final StringExpression username;
    public final ObjectExpression<java.sql.Timestamp> loginTimestamp;
    public final ObjectExpression<java.sql.Timestamp> logoutTimestamp;
    public final EnumExpression causedBy;

    public QSessionLogEntry(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.sessionGuid = new ObjectExpressionImpl<java.util.UUID>(this, "sessionGuid");
        this.httpSessionId = new StringExpressionImpl(this, "httpSessionId");
        this.username = new StringExpressionImpl(this, "username");
        this.loginTimestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "loginTimestamp");
        this.logoutTimestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "logoutTimestamp");
        this.causedBy = new EnumExpressionImpl(this, "causedBy");
    }

    public QSessionLogEntry(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.sessionGuid = new ObjectExpressionImpl<java.util.UUID>(this, "sessionGuid");
        this.httpSessionId = new StringExpressionImpl(this, "httpSessionId");
        this.username = new StringExpressionImpl(this, "username");
        this.loginTimestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "loginTimestamp");
        this.logoutTimestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "logoutTimestamp");
        this.causedBy = new EnumExpressionImpl(this, "causedBy");
    }
}
