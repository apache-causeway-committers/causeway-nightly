package org.apache.causeway.extensions.commandlog.jdo.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QCommandLogEntry extends PersistableExpressionImpl<CommandLogEntry> implements PersistableExpression<CommandLogEntry>
{
    public static final QCommandLogEntry jdoCandidate = candidate("this");

    public static QCommandLogEntry candidate(String name)
    {
        return new QCommandLogEntry(null, name, 5);
    }

    public static QCommandLogEntry candidate()
    {
        return jdoCandidate;
    }

    public static QCommandLogEntry parameter(String name)
    {
        return new QCommandLogEntry(CommandLogEntry.class, name, ExpressionType.PARAMETER);
    }

    public static QCommandLogEntry variable(String name)
    {
        return new QCommandLogEntry(CommandLogEntry.class, name, ExpressionType.VARIABLE);
    }

    public final ObjectExpression<java.util.UUID> interactionId;
    public final StringExpression username;
    public final ObjectExpression<java.sql.Timestamp> timestamp;
    public final ObjectExpression<org.apache.causeway.applib.services.bookmark.Bookmark> target;
    public final EnumExpression executeIn;
    public final ObjectExpression<java.util.UUID> parentInteractionId;
    public final StringExpression logicalMemberIdentifier;
    public final ObjectExpression<org.apache.causeway.schema.cmd.v2.CommandDto> commandDto;
    public final ObjectExpression<java.sql.Timestamp> startedAt;
    public final ObjectExpression<java.sql.Timestamp> completedAt;
    public final ObjectExpression<org.apache.causeway.applib.services.bookmark.Bookmark> result;
    public final StringExpression exception;
    public final EnumExpression replayState;
    public final StringExpression replayStateFailureReason;

    public QCommandLogEntry(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.interactionId = new ObjectExpressionImpl<java.util.UUID>(this, "interactionId");
        this.username = new StringExpressionImpl(this, "username");
        this.timestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "timestamp");
        this.target = new ObjectExpressionImpl<org.apache.causeway.applib.services.bookmark.Bookmark>(this, "target");
        this.executeIn = new EnumExpressionImpl(this, "executeIn");
        this.parentInteractionId = new ObjectExpressionImpl<java.util.UUID>(this, "parentInteractionId");
        this.logicalMemberIdentifier = new StringExpressionImpl(this, "logicalMemberIdentifier");
        this.commandDto = new ObjectExpressionImpl<org.apache.causeway.schema.cmd.v2.CommandDto>(this, "commandDto");
        this.startedAt = new ObjectExpressionImpl<java.sql.Timestamp>(this, "startedAt");
        this.completedAt = new ObjectExpressionImpl<java.sql.Timestamp>(this, "completedAt");
        this.result = new ObjectExpressionImpl<org.apache.causeway.applib.services.bookmark.Bookmark>(this, "result");
        this.exception = new StringExpressionImpl(this, "exception");
        this.replayState = new EnumExpressionImpl(this, "replayState");
        this.replayStateFailureReason = new StringExpressionImpl(this, "replayStateFailureReason");
    }

    public QCommandLogEntry(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.interactionId = new ObjectExpressionImpl<java.util.UUID>(this, "interactionId");
        this.username = new StringExpressionImpl(this, "username");
        this.timestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "timestamp");
        this.target = new ObjectExpressionImpl<org.apache.causeway.applib.services.bookmark.Bookmark>(this, "target");
        this.executeIn = new EnumExpressionImpl(this, "executeIn");
        this.parentInteractionId = new ObjectExpressionImpl<java.util.UUID>(this, "parentInteractionId");
        this.logicalMemberIdentifier = new StringExpressionImpl(this, "logicalMemberIdentifier");
        this.commandDto = new ObjectExpressionImpl<org.apache.causeway.schema.cmd.v2.CommandDto>(this, "commandDto");
        this.startedAt = new ObjectExpressionImpl<java.sql.Timestamp>(this, "startedAt");
        this.completedAt = new ObjectExpressionImpl<java.sql.Timestamp>(this, "completedAt");
        this.result = new ObjectExpressionImpl<org.apache.causeway.applib.services.bookmark.Bookmark>(this, "result");
        this.exception = new StringExpressionImpl(this, "exception");
        this.replayState = new EnumExpressionImpl(this, "replayState");
        this.replayStateFailureReason = new StringExpressionImpl(this, "replayStateFailureReason");
    }
}
