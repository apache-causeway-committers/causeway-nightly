package org.apache.causeway.extensions.commandlog.jdo.integtests.model;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QCounter extends PersistableExpressionImpl<Counter> implements PersistableExpression<Counter>
{
    public static final QCounter jdoCandidate = candidate("this");

    public static QCounter candidate(String name)
    {
        return new QCounter(null, name, 5);
    }

    public static QCounter candidate()
    {
        return jdoCandidate;
    }

    public static QCounter parameter(String name)
    {
        return new QCounter(Counter.class, name, ExpressionType.PARAMETER);
    }

    public static QCounter variable(String name)
    {
        return new QCounter(Counter.class, name, ExpressionType.VARIABLE);
    }

    public final StringExpression name;
    public final NumericExpression<Long> num;
    public final NumericExpression<Long> num2;

    public QCounter(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.name = new StringExpressionImpl(this, "name");
        this.num = new NumericExpressionImpl<Long>(this, "num");
        this.num2 = new NumericExpressionImpl<Long>(this, "num2");
    }

    public QCounter(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.name = new StringExpressionImpl(this, "name");
        this.num = new NumericExpressionImpl<Long>(this, "num");
        this.num2 = new NumericExpressionImpl<Long>(this, "num2");
    }
}
