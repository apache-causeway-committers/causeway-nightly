package org.apache.causeway.extensions.audittrail.jdo.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QAuditTrailEntry extends PersistableExpressionImpl<AuditTrailEntry> implements PersistableExpression<AuditTrailEntry>
{
    public static final QAuditTrailEntry jdoCandidate = candidate("this");

    public static QAuditTrailEntry candidate(String name)
    {
        return new QAuditTrailEntry(null, name, 5);
    }

    public static QAuditTrailEntry candidate()
    {
        return jdoCandidate;
    }

    public static QAuditTrailEntry parameter(String name)
    {
        return new QAuditTrailEntry(AuditTrailEntry.class, name, ExpressionType.PARAMETER);
    }

    public static QAuditTrailEntry variable(String name)
    {
        return new QAuditTrailEntry(AuditTrailEntry.class, name, ExpressionType.VARIABLE);
    }

    public final StringExpression username;
    public final ObjectExpression<java.sql.Timestamp> timestamp;
    public final ObjectExpression<java.util.UUID> interactionId;
    public final NumericExpression<Integer> sequence;
    public final ObjectExpression<org.apache.causeway.applib.services.bookmark.Bookmark> target;
    public final StringExpression logicalMemberIdentifier;
    public final StringExpression propertyId;
    public final StringExpression preValue;
    public final StringExpression postValue;

    public QAuditTrailEntry(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.username = new StringExpressionImpl(this, "username");
        this.timestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "timestamp");
        this.interactionId = new ObjectExpressionImpl<java.util.UUID>(this, "interactionId");
        this.sequence = new NumericExpressionImpl<Integer>(this, "sequence");
        this.target = new ObjectExpressionImpl<org.apache.causeway.applib.services.bookmark.Bookmark>(this, "target");
        this.logicalMemberIdentifier = new StringExpressionImpl(this, "logicalMemberIdentifier");
        this.propertyId = new StringExpressionImpl(this, "propertyId");
        this.preValue = new StringExpressionImpl(this, "preValue");
        this.postValue = new StringExpressionImpl(this, "postValue");
    }

    public QAuditTrailEntry(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.username = new StringExpressionImpl(this, "username");
        this.timestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "timestamp");
        this.interactionId = new ObjectExpressionImpl<java.util.UUID>(this, "interactionId");
        this.sequence = new NumericExpressionImpl<Integer>(this, "sequence");
        this.target = new ObjectExpressionImpl<org.apache.causeway.applib.services.bookmark.Bookmark>(this, "target");
        this.logicalMemberIdentifier = new StringExpressionImpl(this, "logicalMemberIdentifier");
        this.propertyId = new StringExpressionImpl(this, "propertyId");
        this.preValue = new StringExpressionImpl(this, "preValue");
        this.postValue = new StringExpressionImpl(this, "postValue");
    }
}
