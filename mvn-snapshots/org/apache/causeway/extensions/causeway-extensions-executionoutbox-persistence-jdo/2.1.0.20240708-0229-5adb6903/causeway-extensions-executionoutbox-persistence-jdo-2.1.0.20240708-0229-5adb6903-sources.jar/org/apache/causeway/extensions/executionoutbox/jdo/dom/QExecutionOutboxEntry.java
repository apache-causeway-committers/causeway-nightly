package org.apache.causeway.extensions.executionoutbox.jdo.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QExecutionOutboxEntry extends PersistableExpressionImpl<ExecutionOutboxEntry> implements PersistableExpression<ExecutionOutboxEntry>
{
    public static final QExecutionOutboxEntry jdoCandidate = candidate("this");

    public static QExecutionOutboxEntry candidate(String name)
    {
        return new QExecutionOutboxEntry(null, name, 5);
    }

    public static QExecutionOutboxEntry candidate()
    {
        return jdoCandidate;
    }

    public static QExecutionOutboxEntry parameter(String name)
    {
        return new QExecutionOutboxEntry(ExecutionOutboxEntry.class, name, ExpressionType.PARAMETER);
    }

    public static QExecutionOutboxEntry variable(String name)
    {
        return new QExecutionOutboxEntry(ExecutionOutboxEntry.class, name, ExpressionType.VARIABLE);
    }

    public final ObjectExpression<java.util.UUID> interactionId;
    public final NumericExpression<Integer> sequence;
    public final EnumExpression executionType;
    public final StringExpression username;
    public final ObjectExpression<java.sql.Timestamp> timestamp;
    public final ObjectExpression<org.apache.causeway.applib.services.bookmark.Bookmark> target;
    public final StringExpression logicalMemberIdentifier;
    public final ObjectExpression<org.apache.causeway.schema.ixn.v2.InteractionDto> interactionDto;
    public final ObjectExpression<java.sql.Timestamp> startedAt;
    public final ObjectExpression<java.sql.Timestamp> completedAt;

    public QExecutionOutboxEntry(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.interactionId = new ObjectExpressionImpl<java.util.UUID>(this, "interactionId");
        this.sequence = new NumericExpressionImpl<Integer>(this, "sequence");
        this.executionType = new EnumExpressionImpl(this, "executionType");
        this.username = new StringExpressionImpl(this, "username");
        this.timestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "timestamp");
        this.target = new ObjectExpressionImpl<org.apache.causeway.applib.services.bookmark.Bookmark>(this, "target");
        this.logicalMemberIdentifier = new StringExpressionImpl(this, "logicalMemberIdentifier");
        this.interactionDto = new ObjectExpressionImpl<org.apache.causeway.schema.ixn.v2.InteractionDto>(this, "interactionDto");
        this.startedAt = new ObjectExpressionImpl<java.sql.Timestamp>(this, "startedAt");
        this.completedAt = new ObjectExpressionImpl<java.sql.Timestamp>(this, "completedAt");
    }

    public QExecutionOutboxEntry(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.interactionId = new ObjectExpressionImpl<java.util.UUID>(this, "interactionId");
        this.sequence = new NumericExpressionImpl<Integer>(this, "sequence");
        this.executionType = new EnumExpressionImpl(this, "executionType");
        this.username = new StringExpressionImpl(this, "username");
        this.timestamp = new ObjectExpressionImpl<java.sql.Timestamp>(this, "timestamp");
        this.target = new ObjectExpressionImpl<org.apache.causeway.applib.services.bookmark.Bookmark>(this, "target");
        this.logicalMemberIdentifier = new StringExpressionImpl(this, "logicalMemberIdentifier");
        this.interactionDto = new ObjectExpressionImpl<org.apache.causeway.schema.ixn.v2.InteractionDto>(this, "interactionDto");
        this.startedAt = new ObjectExpressionImpl<java.sql.Timestamp>(this, "startedAt");
        this.completedAt = new ObjectExpressionImpl<java.sql.Timestamp>(this, "completedAt");
    }
}
