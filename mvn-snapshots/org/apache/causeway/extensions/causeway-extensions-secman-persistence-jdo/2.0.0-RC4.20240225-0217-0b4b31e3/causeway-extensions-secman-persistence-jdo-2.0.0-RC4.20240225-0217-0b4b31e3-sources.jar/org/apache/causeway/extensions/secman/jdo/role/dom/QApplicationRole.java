package org.apache.causeway.extensions.secman.jdo.role.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QApplicationRole extends PersistableExpressionImpl<ApplicationRole> implements PersistableExpression<ApplicationRole>
{
    public static final QApplicationRole jdoCandidate = candidate("this");

    public static QApplicationRole candidate(String name)
    {
        return new QApplicationRole(null, name, 5);
    }

    public static QApplicationRole candidate()
    {
        return jdoCandidate;
    }

    public static QApplicationRole parameter(String name)
    {
        return new QApplicationRole(ApplicationRole.class, name, ExpressionType.PARAMETER);
    }

    public static QApplicationRole variable(String name)
    {
        return new QApplicationRole(ApplicationRole.class, name, ExpressionType.VARIABLE);
    }

    public final StringExpression name;
    public final StringExpression description;
    public final CollectionExpression users;

    public QApplicationRole(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.name = new StringExpressionImpl(this, "name");
        this.description = new StringExpressionImpl(this, "description");
        this.users = new CollectionExpressionImpl(this, "users");
    }

    public QApplicationRole(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.name = new StringExpressionImpl(this, "name");
        this.description = new StringExpressionImpl(this, "description");
        this.users = new CollectionExpressionImpl(this, "users");
    }
}
