package org.apache.causeway.extensions.secman.jdo.tenancy.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QApplicationTenancy extends PersistableExpressionImpl<ApplicationTenancy> implements PersistableExpression<ApplicationTenancy>
{
    public static final QApplicationTenancy jdoCandidate = candidate("this");

    public static QApplicationTenancy candidate(String name)
    {
        return new QApplicationTenancy(null, name, 5);
    }

    public static QApplicationTenancy candidate()
    {
        return jdoCandidate;
    }

    public static QApplicationTenancy parameter(String name)
    {
        return new QApplicationTenancy(ApplicationTenancy.class, name, ExpressionType.PARAMETER);
    }

    public static QApplicationTenancy variable(String name)
    {
        return new QApplicationTenancy(ApplicationTenancy.class, name, ExpressionType.VARIABLE);
    }

    public final StringExpression name;
    public final StringExpression path;
    public final org.apache.causeway.extensions.secman.jdo.tenancy.dom.QApplicationTenancy parent;
    public final CollectionExpression children;

    public QApplicationTenancy(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.name = new StringExpressionImpl(this, "name");
        this.path = new StringExpressionImpl(this, "path");
        if (depth > 0)
        {
            this.parent = new org.apache.causeway.extensions.secman.jdo.tenancy.dom.QApplicationTenancy(this, "parent", depth-1);
        }
        else
        {
            this.parent = null;
        }
        this.children = new CollectionExpressionImpl(this, "children");
    }

    public QApplicationTenancy(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.name = new StringExpressionImpl(this, "name");
        this.path = new StringExpressionImpl(this, "path");
        this.parent = new org.apache.causeway.extensions.secman.jdo.tenancy.dom.QApplicationTenancy(this, "parent", 5);
        this.children = new CollectionExpressionImpl(this, "children");
    }
}
