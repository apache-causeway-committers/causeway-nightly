/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.causeway.viewer.wicket.ui.components;

import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.model.IModel;

import org.apache.causeway.core.config.CausewayConfiguration;
import org.apache.causeway.core.config.viewer.web.WebAppContextPath;
import org.apache.causeway.core.metamodel.context.HasMetaModelContext;

/**
 * Provides all the system dependencies for sub-classes.
 * @since 2.0
 */
public abstract class LabelBase
extends Label
implements HasMetaModelContext {

    private static final long serialVersionUID = 1L;

    public LabelBase(final String id) {
        super(id);
    }

    public LabelBase(final String id, final IModel<?> model) {
        super(id, model);
    }

    private transient CausewayConfiguration causewayConfiguration;
    private transient WebAppContextPath webAppContextPath;

    public CausewayConfiguration getCausewayConfiguration() {
        return causewayConfiguration = computeIfAbsent(CausewayConfiguration.class, causewayConfiguration);
    }

    @Override
    public WebAppContextPath getWebAppContextPath() {
        return webAppContextPath = computeIfAbsent(WebAppContextPath.class, webAppContextPath);
    }

    // -- HELPER

    private <X> X computeIfAbsent(final Class<X> type, final X existingIfAny) {
        return existingIfAny!=null
                ? existingIfAny
                : getMetaModelContext().lookupServiceElseFail(type);
    }

}
