/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.extensions.secman.integration;

import org.apache.isis.extensions.secman.integration.authenticator.AuthenticatorSecmanAutoConfiguration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import org.apache.isis.extensions.secman.applib.IsisModuleExtSecmanApplib;
import org.apache.isis.extensions.secman.integration.authorizor.AuthorizorSecman;
import org.apache.isis.extensions.secman.integration.facets.TenantedAuthorizationPostProcessor;
import org.apache.isis.extensions.secman.integration.permissions.ApplicationFeatureIdTransformerIdentity;
import org.apache.isis.extensions.secman.integration.permissions.PermissionsEvaluationServiceForSecman;
import org.apache.isis.extensions.secman.integration.spiimpl.ImpersonateMenuAdvisorForSecman;
import org.apache.isis.extensions.secman.integration.spiimpl.TableColumnVisibilityServiceForSecman;
import org.apache.isis.extensions.secman.integration.usermementorefiner.UserMementoRefinerFromApplicationUser;
import org.apache.isis.extensions.secman.integration.userreg.UserRegistrationServiceForSecman;

/**
 * @since 2.0 {@index}
 */
@Configuration
@Import({
        // Module
        IsisModuleExtSecmanApplib.class,

        // @Component or @Service
        AuthorizorSecman.class,
        TenantedAuthorizationPostProcessor.Register.class,
        TableColumnVisibilityServiceForSecman.class,
        ImpersonateMenuAdvisorForSecman.class, //not activated by default yet
        PermissionsEvaluationServiceForSecman.class,
        ApplicationFeatureIdTransformerIdentity.class,
        UserRegistrationServiceForSecman.class,

        UserMementoRefinerFromApplicationUser.class,

        // auto-configurations
        AuthenticatorSecmanAutoConfiguration.class,

})
public class IsisModuleExtSecmanIntegration {

}
