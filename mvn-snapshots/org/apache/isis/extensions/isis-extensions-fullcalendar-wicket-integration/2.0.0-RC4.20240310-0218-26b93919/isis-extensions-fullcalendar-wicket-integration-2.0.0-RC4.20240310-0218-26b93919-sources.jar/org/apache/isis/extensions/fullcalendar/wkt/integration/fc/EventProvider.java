/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.extensions.fullcalendar.wkt.integration.fc;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.NoSuchElementException;

import org.joda.time.DateTime;

import org.apache.isis.valuetypes.jodatime.applib.value.JodaTimeConverters;

public interface EventProvider extends Serializable {

	Event getEventForId(String id) throws NoSuchElementException;

	default Collection<Event> getEvents(final ZonedDateTime start, final ZonedDateTime end) {
	    return getEvents(JodaTimeConverters.toJoda(start), JodaTimeConverters.toJoda(end));
	}

	@Deprecated
    default Collection<Event> getEvents(final DateTime start, final DateTime end) {
        return getEvents(JodaTimeConverters.fromJoda(start), JodaTimeConverters.fromJoda(end));
    }

//
//    default Collection<Event> getEvents(@NonNull final ImmutablePair<ZonedDateTime, ZonedDateTime> interval) {
//        return getEvents(interval.getLeft(), interval.getRight());
//    }
}
