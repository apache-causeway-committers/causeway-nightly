package org.apache.isis.extensions.secman.jdo.permission.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QApplicationPermission extends PersistableExpressionImpl<ApplicationPermission> implements PersistableExpression<ApplicationPermission>
{
    public static final QApplicationPermission jdoCandidate = candidate("this");

    public static QApplicationPermission candidate(String name)
    {
        return new QApplicationPermission(null, name, 5);
    }

    public static QApplicationPermission candidate()
    {
        return jdoCandidate;
    }

    public static QApplicationPermission parameter(String name)
    {
        return new QApplicationPermission(ApplicationPermission.class, name, ExpressionType.PARAMETER);
    }

    public static QApplicationPermission variable(String name)
    {
        return new QApplicationPermission(ApplicationPermission.class, name, ExpressionType.VARIABLE);
    }

    public final org.apache.isis.extensions.secman.jdo.role.dom.QApplicationRole role;
    public final EnumExpression rule;
    public final EnumExpression mode;
    public final EnumExpression featureSort;
    public final StringExpression featureFqn;

    public QApplicationPermission(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        if (depth > 0)
        {
            this.role = new org.apache.isis.extensions.secman.jdo.role.dom.QApplicationRole(this, "role", depth-1);
        }
        else
        {
            this.role = null;
        }
        this.rule = new EnumExpressionImpl(this, "rule");
        this.mode = new EnumExpressionImpl(this, "mode");
        this.featureSort = new EnumExpressionImpl(this, "featureSort");
        this.featureFqn = new StringExpressionImpl(this, "featureFqn");
    }

    public QApplicationPermission(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.role = new org.apache.isis.extensions.secman.jdo.role.dom.QApplicationRole(this, "role", 5);
        this.rule = new EnumExpressionImpl(this, "rule");
        this.mode = new EnumExpressionImpl(this, "mode");
        this.featureSort = new EnumExpressionImpl(this, "featureSort");
        this.featureFqn = new StringExpressionImpl(this, "featureFqn");
    }
}
