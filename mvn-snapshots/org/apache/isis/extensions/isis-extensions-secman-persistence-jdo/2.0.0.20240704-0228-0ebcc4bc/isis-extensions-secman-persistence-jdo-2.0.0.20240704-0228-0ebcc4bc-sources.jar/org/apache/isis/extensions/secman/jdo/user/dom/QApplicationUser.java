package org.apache.isis.extensions.secman.jdo.user.dom;

import javax.annotation.processing.Generated;
import javax.jdo.query.*;
import org.datanucleus.api.jdo.query.*;

@Generated(value="org.datanucleus.jdo.query.JDOQueryProcessor")
public class QApplicationUser extends PersistableExpressionImpl<ApplicationUser> implements PersistableExpression<ApplicationUser>
{
    public static final QApplicationUser jdoCandidate = candidate("this");

    public static QApplicationUser candidate(String name)
    {
        return new QApplicationUser(null, name, 5);
    }

    public static QApplicationUser candidate()
    {
        return jdoCandidate;
    }

    public static QApplicationUser parameter(String name)
    {
        return new QApplicationUser(ApplicationUser.class, name, ExpressionType.PARAMETER);
    }

    public static QApplicationUser variable(String name)
    {
        return new QApplicationUser(ApplicationUser.class, name, ExpressionType.VARIABLE);
    }

    public final StringExpression username;
    public final StringExpression familyName;
    public final StringExpression givenName;
    public final StringExpression knownAs;
    public final StringExpression emailAddress;
    public final StringExpression phoneNumber;
    public final StringExpression faxNumber;
    public final ObjectExpression<java.util.Locale> language;
    public final ObjectExpression<java.util.Locale> numberFormat;
    public final ObjectExpression<java.util.Locale> timeFormat;
    public final StringExpression atPath;
    public final EnumExpression accountType;
    public final EnumExpression status;
    public final StringExpression encryptedPassword;
    public final CollectionExpression roles;

    public QApplicationUser(PersistableExpression parent, String name, int depth)
    {
        super(parent, name);
        this.username = new StringExpressionImpl(this, "username");
        this.familyName = new StringExpressionImpl(this, "familyName");
        this.givenName = new StringExpressionImpl(this, "givenName");
        this.knownAs = new StringExpressionImpl(this, "knownAs");
        this.emailAddress = new StringExpressionImpl(this, "emailAddress");
        this.phoneNumber = new StringExpressionImpl(this, "phoneNumber");
        this.faxNumber = new StringExpressionImpl(this, "faxNumber");
        this.language = new ObjectExpressionImpl<java.util.Locale>(this, "language");
        this.numberFormat = new ObjectExpressionImpl<java.util.Locale>(this, "numberFormat");
        this.timeFormat = new ObjectExpressionImpl<java.util.Locale>(this, "timeFormat");
        this.atPath = new StringExpressionImpl(this, "atPath");
        this.accountType = new EnumExpressionImpl(this, "accountType");
        this.status = new EnumExpressionImpl(this, "status");
        this.encryptedPassword = new StringExpressionImpl(this, "encryptedPassword");
        this.roles = new CollectionExpressionImpl(this, "roles");
    }

    public QApplicationUser(Class<?> type, String name, ExpressionType exprType)
    {
        super(type, name, exprType);
        this.username = new StringExpressionImpl(this, "username");
        this.familyName = new StringExpressionImpl(this, "familyName");
        this.givenName = new StringExpressionImpl(this, "givenName");
        this.knownAs = new StringExpressionImpl(this, "knownAs");
        this.emailAddress = new StringExpressionImpl(this, "emailAddress");
        this.phoneNumber = new StringExpressionImpl(this, "phoneNumber");
        this.faxNumber = new StringExpressionImpl(this, "faxNumber");
        this.language = new ObjectExpressionImpl<java.util.Locale>(this, "language");
        this.numberFormat = new ObjectExpressionImpl<java.util.Locale>(this, "numberFormat");
        this.timeFormat = new ObjectExpressionImpl<java.util.Locale>(this, "timeFormat");
        this.atPath = new StringExpressionImpl(this, "atPath");
        this.accountType = new EnumExpressionImpl(this, "accountType");
        this.status = new EnumExpressionImpl(this, "status");
        this.encryptedPassword = new StringExpressionImpl(this, "encryptedPassword");
        this.roles = new CollectionExpressionImpl(this, "roles");
    }
}
