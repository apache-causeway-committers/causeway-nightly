/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.viewer.graphql.viewer.integration;

import javax.annotation.PostConstruct;

import graphql.GraphQL;
import graphql.execution.SimpleDataFetcherExceptionHandler;
import graphql.schema.GraphQLSchema;

import org.apache.isis.viewer.graphql.model.domain.simple.mutation.GqlvTopLevelMutationSimpleSchema;
import org.apache.isis.viewer.graphql.model.domain.simple.query.SimpleTopLevelQuery;

import org.springframework.graphql.execution.GraphQlSource;
import org.springframework.stereotype.Service;

import org.apache.isis.core.config.IsisConfiguration;
import org.apache.isis.core.config.environment.IsisSystemEnvironment;
import org.apache.isis.core.config.metamodel.specloader.IntrospectionMode;
import org.apache.isis.core.metamodel.specloader.SpecificationLoader;
import org.apache.isis.viewer.graphql.model.context.Context;
import org.apache.isis.viewer.graphql.model.domain.GqlvAbstractCustom;
import org.apache.isis.viewer.graphql.model.domain.rich.query.RichTopLevelQuery;
import org.apache.isis.viewer.graphql.model.registry.GraphQLTypeRegistry;
import org.apache.isis.viewer.graphql.model.toplevel.GqlvTopLevelQueryBothSchemas;
import org.apache.isis.viewer.graphql.model.domain.rich.mutation.GqlvTopLevelMutationRichSchema;

import lombok.val;

@Service()
//@RequiredArgsConstructor(onConstructor_ = {@Inject})
public class GraphQlSourceForIsis implements GraphQlSource {

    private final IsisConfiguration isisConfiguration;
    private final IsisSystemEnvironment isisSystemEnvironment;
    private final SpecificationLoader specificationLoader;
    private final GraphQLTypeRegistry graphQLTypeRegistry;
    private final Context context;
    private final AsyncExecutionStrategyResolvingWithinInteraction executionStrategy;

    private IsisConfiguration.Viewer.Graphql graphqlConfiguration;

    public GraphQlSourceForIsis(
            final IsisConfiguration isisConfiguration,
            final IsisSystemEnvironment isisSystemEnvironment,
            final SpecificationLoader specificationLoader,
            final GraphQLTypeRegistry graphQLTypeRegistry,
            final Context context,
            final AsyncExecutionStrategyResolvingWithinInteraction executionStrategy) {
        this.isisConfiguration = isisConfiguration;
        this.isisSystemEnvironment = isisSystemEnvironment;
        this.specificationLoader = specificationLoader;
        this.graphQLTypeRegistry = graphQLTypeRegistry;
        this.context = context;
        this.executionStrategy = executionStrategy;

        this.graphqlConfiguration = isisConfiguration.getViewer().getGraphql();
    }

    @PostConstruct
    public void init() {
        boolean fullyIntrospect = IntrospectionMode.isFullIntrospect(isisConfiguration, isisSystemEnvironment);
        if (!fullyIntrospect) {
            throw new IllegalStateException("GraphQL requires full introspection mode");
        }
    }

    GraphQL graphQL;

    @Override
    public GraphQL graphQl() {
        if (graphQL == null) {
            graphQL = GraphQL.newGraphQL(schema())
                    .defaultDataFetcherExceptionHandler(new SimpleDataFetcherExceptionHandler())
                    .queryExecutionStrategy(executionStrategy)
                    .mutationExecutionStrategy(executionStrategy)
                    .build();
        }
        return graphQL;
    }

    @Override
    public GraphQLSchema schema() {

        val fullyIntrospected = specificationLoader.isMetamodelFullyIntrospected();
        if (!fullyIntrospected) {
            throw new IllegalStateException("Metamodel is not fully introspected");
        }

        val topLevelQuery = determineTopLevelQueryFrom(graphqlConfiguration.getSchemaStyle());
        val topLevelMutation = determineTopLevelMutationFrom(graphqlConfiguration.getSchemaStyle());

        topLevelQuery.addDataFetchers();
        topLevelMutation.addDataFetchers();

        // finalize the fetcher/mutator code that's been added
        val codeRegistry = context.codeRegistryBuilder.build();

        // build the schema
        return GraphQLSchema.newSchema()
                .query(topLevelQuery.getGqlObjectType())
                .mutation(topLevelMutation.getGqlObjectType())
                .additionalTypes(graphQLTypeRegistry.getGraphQLTypes())
                .codeRegistry(codeRegistry)
                .build();
    }

    private GqlvAbstractCustom determineTopLevelQueryFrom(
            final IsisConfiguration.Viewer.Graphql.SchemaStyle schemaStyle) {
        switch (schemaStyle) {
            case SIMPLE_ONLY:
                return new SimpleTopLevelQuery(context);
            case RICH_ONLY:
                return new RichTopLevelQuery(context);
            case SIMPLE_AND_RICH:
            case RICH_AND_SIMPLE:
                return new GqlvTopLevelQueryBothSchemas(context);
            default:
                // shouldn't happen
                throw new IllegalStateException(String.format(
                        "Configured SchemaStyle '%s' not recognised", schemaStyle));
        }
    }
    private GqlvAbstractCustom determineTopLevelMutationFrom(
            final IsisConfiguration.Viewer.Graphql.SchemaStyle schemaStyle) {
        switch (schemaStyle) {
            case SIMPLE_ONLY:
                return new GqlvTopLevelMutationSimpleSchema(context);
            case RICH_ONLY:
                return new GqlvTopLevelMutationRichSchema(context);
            case SIMPLE_AND_RICH:
                return new GqlvTopLevelMutationSimpleSchema(context);
            case RICH_AND_SIMPLE:
                return new GqlvTopLevelMutationRichSchema(context);
            default:
                // shouldn't happen
                throw new IllegalStateException(String.format(
                        "Configured SchemaStyle '%s' not recognised", schemaStyle));
        }
    }
}
