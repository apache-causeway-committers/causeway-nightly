module org.apache.isis.incubator.viewer.graphql.applib {
    exports org.apache.isis.viewer.graphql.applib;
    exports org.apache.isis.viewer.graphql.applib.auth;
    exports org.apache.isis.viewer.graphql.applib.marshallers;

    requires spring.context;
    requires com.graphqljava;
    requires org.apache.isis.core.config;
    requires org.apache.isis.core.metamodel;
}
