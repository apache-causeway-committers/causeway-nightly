 /*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.viewer.graphql.model.domain;

 import static graphql.schema.GraphQLFieldDefinition.newFieldDefinition;
import static graphql.schema.GraphQLNonNull.nonNull;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.isis.applib.annotation.Where;
import org.apache.isis.applib.services.bookmark.BookmarkService;
import org.apache.isis.commons.collections.Can;
import org.apache.isis.core.metamodel.consent.InteractionInitiatedBy;
import org.apache.isis.core.metamodel.interactions.managed.ManagedAction;
import org.apache.isis.core.metamodel.interactions.managed.ParameterNegotiationModel;
import org.apache.isis.core.metamodel.object.ManagedObject;
import org.apache.isis.core.metamodel.spec.feature.ObjectAction;
import org.apache.isis.viewer.graphql.model.context.Context;
import org.apache.isis.viewer.graphql.model.fetcher.BookmarkedPojo;
import org.apache.isis.viewer.graphql.model.mmproviders.ObjectActionParameterProvider;
import org.apache.isis.viewer.graphql.model.mmproviders.ObjectActionProvider;
import org.apache.isis.viewer.graphql.model.mmproviders.ObjectSpecificationProvider;
import org.apache.isis.viewer.graphql.model.types.TypeMapper;

import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLArgument;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLList;
import lombok.val;
import lombok.extern.log4j.Log4j2;

 @Log4j2
 public class GqlvActionParamAutoComplete {

     private static final String SEARCH_PARAM_NAME = "search";

     private final Holder holder;
     private final Context context;

     /**
      * Populated iff there is an autocomplete for this parameter.
      */
     private final GraphQLFieldDefinition field;

     public GqlvActionParamAutoComplete(
             final Holder holder,
             final Context context) {
         this.holder = holder;
         this.context = context;

         val objectActionParameter = holder.getObjectActionParameter();
         if (objectActionParameter.hasAutoComplete()) {
             val elementType = objectActionParameter.getElementType();
             val fieldBuilder = newFieldDefinition()
                     .name("autoComplete")
                     .type(GraphQLList.list(context.typeMapper.outputTypeFor(elementType)));
             holder.addGqlArguments(holder.getObjectAction(), fieldBuilder, TypeMapper.InputContext.AUTOCOMPLETE, holder.getParamNum());
             fieldBuilder.argument(GraphQLArgument.newArgument()
                     .name(SEARCH_PARAM_NAME)
                     .type(nonNull(context.typeMapper.scalarTypeFor(String.class))))
                     .build();
             this.field = holder.addField(fieldBuilder.build());
         } else {
             this.field = null;
         }
     }

     boolean hasAutoComplete() {
         return field != null;
     }

     public void addDataFetcher() {
         context.codeRegistryBuilder.dataFetcher(
                 holder.coordinatesFor(field),
                 this::choices
         );
     }

     private List<Object> choices(final DataFetchingEnvironment dataFetchingEnvironment) {

         val sourcePojo = BookmarkedPojo.sourceFrom(dataFetchingEnvironment);
         val objectSpecification = context.specificationLoader.loadSpecification(sourcePojo.getClass());
         if (objectSpecification == null) {
             return Collections.emptyList();
         }

         val objectAction = holder.getObjectAction();
         val managedObject = ManagedObject.adaptSingular(objectSpecification, sourcePojo);

         val objectActionParameter = objectAction.getParameterById(holder.getObjectActionParameter().getId());
         val argumentManagedObjects = holder.argumentManagedObjectsFor(dataFetchingEnvironment, objectAction, context.bookmarkService);

         val managedAction = ManagedAction.of(managedObject, objectAction, Where.ANYWHERE);
         val pendingArgs = ParameterNegotiationModel.of(managedAction, argumentManagedObjects);
         val searchArg = dataFetchingEnvironment.<String>getArgument(SEARCH_PARAM_NAME);
         val autoCompleteManagedObjects = objectActionParameter.getAutoComplete(pendingArgs, searchArg, InteractionInitiatedBy.USER);

         return autoCompleteManagedObjects.stream()
                    .map(ManagedObject::getPojo)
                    .collect(Collectors.toList());
     }

     public interface Holder
             extends GqlvHolder,
             ObjectSpecificationProvider,
             ObjectActionProvider,
             ObjectActionParameterProvider {
         GqlvActionParam.Holder getHolder();

         void addGqlArguments(
                 ObjectAction objectAction,
                 GraphQLFieldDefinition.Builder fieldBuilder,
                 TypeMapper.InputContext inputContext,
                 int paramNum);

         Can<ManagedObject> argumentManagedObjectsFor(
                 DataFetchingEnvironment dataFetchingEnvironment,
                 ObjectAction objectAction,
                 BookmarkService bookmarkService);
     }
 }
