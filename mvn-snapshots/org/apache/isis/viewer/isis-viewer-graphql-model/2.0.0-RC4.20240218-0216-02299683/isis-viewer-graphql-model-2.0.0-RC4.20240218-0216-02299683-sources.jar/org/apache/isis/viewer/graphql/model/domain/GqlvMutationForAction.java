/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.viewer.graphql.model.domain;

import java.util.ArrayList;

import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLArgument;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLList;
import graphql.schema.GraphQLOutputType;
import graphql.schema.GraphQLType;

import static graphql.schema.GraphQLFieldDefinition.newFieldDefinition;

import org.springframework.lang.Nullable;

import org.apache.isis.applib.annotation.Where;
import org.apache.isis.commons.collections.Can;
import org.apache.isis.core.metamodel.consent.InteractionInitiatedBy;
import org.apache.isis.core.metamodel.facets.actcoll.typeof.TypeOfFacet;
import org.apache.isis.core.metamodel.object.ManagedObject;
import org.apache.isis.core.metamodel.spec.ObjectSpecification;
import org.apache.isis.core.metamodel.spec.feature.ObjectAction;
import org.apache.isis.core.metamodel.spec.feature.ObjectActionParameter;
import org.apache.isis.core.metamodel.spec.feature.OneToManyActionParameter;
import org.apache.isis.core.metamodel.spec.feature.OneToOneActionParameter;
import org.apache.isis.viewer.graphql.model.context.Context;
import org.apache.isis.viewer.graphql.model.exceptions.DisabledException;
import org.apache.isis.viewer.graphql.model.exceptions.HiddenException;
import org.apache.isis.viewer.graphql.model.types.TypeMapper;

import lombok.val;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class GqlvMutationForAction extends GqlvAbstract {

    private final ObjectSpecification objectSpec;
    private final ObjectAction objectAction;
    private String argumentName;

    public GqlvMutationForAction(
            final ObjectSpecification objectSpec,
            final ObjectAction objectAction,
            final Context context) {
        super(context);
        this.objectSpec = objectSpec;
        this.objectAction = objectAction;

        this.argumentName = context.isisConfiguration.getViewer().getGraphql().getMutation().getTargetArgName();

        GraphQLOutputType type = typeFor(objectAction);
        if (type != null) {
            val fieldBuilder = newFieldDefinition()
                    .name(fieldName(objectSpec, objectAction))
                    .type(type);
            addGqlArguments(fieldBuilder);
            setField(fieldBuilder.build());
        } else {
            setField(null);
        }
    }

    private static String fieldName(
            final ObjectSpecification objectSpecification,
            final ObjectAction objectAction) {
        return TypeNames.objectTypeNameFor(objectSpecification) + "__" + objectAction.getId();
    }

    @Nullable
    private GraphQLOutputType typeFor(final ObjectAction objectAction){
        ObjectSpecification objectSpecification = objectAction.getReturnType();
        switch (objectSpecification.getBeanSort()){

            case COLLECTION:

                TypeOfFacet facet = objectAction.getFacet(TypeOfFacet.class);
                if (facet == null) {
                    log.warn("Unable to locate TypeOfFacet for {}", objectAction.getFeatureIdentifier().getFullIdentityString());
                    return null;
                }
                val objectSpecificationOfCollectionElement = facet.elementSpec();
                GraphQLType wrappedType = context.typeMapper.outputTypeFor(objectSpecificationOfCollectionElement);
                if (wrappedType == null) {
                    log.warn("Unable to create wrapped type of for {} for action {}",
                            objectSpecificationOfCollectionElement.getFullIdentifier(),
                            objectAction.getFeatureIdentifier().getFullIdentityString());
                    return null;
                }
                return GraphQLList.list(wrappedType);

            case VALUE:
            case ENTITY:
            case VIEW_MODEL:
            default:
                return context.typeMapper.outputTypeFor(objectSpecification);

        }
    }

    @Override
    protected Object fetchData(final DataFetchingEnvironment environment) {

        val isService = objectSpec.getBeanSort().isManagedBeanContributing();

        Object sourcePojo;
        if (isService) {
            sourcePojo = context.serviceRegistry.lookupServiceElseFail(objectSpec.getCorrespondingClass());
        } else {
            Object target = environment.getArgument(argumentName);
            sourcePojo = GqlvAction.asPojo(objectSpec, target, context.bookmarkService, environment)
                    .orElseThrow(); // TODO: better error handling if no such object found.
        }

        ManagedObject managedObject = ManagedObject.adaptSingular(objectSpec, sourcePojo);

        val visibleConsent = objectAction.isVisible(managedObject, InteractionInitiatedBy.USER, Where.ANYWHERE);
        if (visibleConsent.isVetoed()) {
            throw new HiddenException(objectAction.getFeatureIdentifier());
        }

        val usableConsent = objectAction.isUsable(managedObject, InteractionInitiatedBy.USER, Where.ANYWHERE);
        if (usableConsent.isVetoed()) {
            throw new DisabledException(objectAction.getFeatureIdentifier());
        }

        val head = objectAction.interactionHead(managedObject);
        val argumentManagedObjects = argumentManagedObjectsFor(environment, objectAction);

        val validityConsent = objectAction.isArgumentSetValid(head, argumentManagedObjects, InteractionInitiatedBy.USER);
        if (validityConsent.isVetoed()) {
            throw new IllegalArgumentException(validityConsent.getReasonAsString().orElse("Invalid"));
        }

        val resultManagedObject = objectAction.execute(head, argumentManagedObjects, InteractionInitiatedBy.USER);
        return resultManagedObject.getPojo();
    }


    // TODO: adapted from GqlvAction - rationalize?
    private void addGqlArguments(final GraphQLFieldDefinition.Builder fieldBuilder) {

        val arguments = new ArrayList<GraphQLArgument>();
        val argName = context.isisConfiguration.getViewer().getGraphql().getMutation().getTargetArgName();

        // add target (if not a service)
        if (! objectSpec.getBeanSort().isManagedBeanContributing()) {
            arguments.add(
                    GraphQLArgument.newArgument()
                            .name(argName)
                            .type(context.typeMapper.inputTypeFor(objectSpec))
                            .build()
            );
        }

        val parameters = objectAction.getParameters();
        parameters.stream()
                .map(this::gqlArgumentFor)
                .forEach(arguments::add);

        if (!arguments.isEmpty()) {
            fieldBuilder.arguments(arguments);
        }
    }

    // adapted from GqlvAction
    GraphQLArgument gqlArgumentFor(final ObjectActionParameter objectActionParameter) {
        return objectActionParameter.isPlural()
                ? gqlArgumentFor((OneToManyActionParameter) objectActionParameter)
                : gqlArgumentFor((OneToOneActionParameter) objectActionParameter);
    }

    // adapted from GqlvAction
    GraphQLArgument gqlArgumentFor(final OneToOneActionParameter oneToOneActionParameter) {
        return GraphQLArgument.newArgument()
                .name(oneToOneActionParameter.getId())
                .type(context.typeMapper.inputTypeFor(oneToOneActionParameter, TypeMapper.InputContext.INVOKE))
                .build();
    }

    // adapted from GqlvAction
    GraphQLArgument gqlArgumentFor(final OneToManyActionParameter oneToManyActionParameter) {
        return GraphQLArgument.newArgument()
                .name(oneToManyActionParameter.getId())
                .type(context.typeMapper.inputTypeFor(oneToManyActionParameter))
                .build();
    }

    private Can<ManagedObject> argumentManagedObjectsFor(
            final DataFetchingEnvironment dataFetchingEnvironment,
            final ObjectAction objectAction) {
        return GqlvAction.argumentManagedObjectsFor(dataFetchingEnvironment, objectAction, context);
    }


}
