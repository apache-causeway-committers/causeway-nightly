module org.apache.isis.incubator.viewer.graphql.model {
    exports org.apache.isis.viewer.graphql.model;
    exports org.apache.isis.viewer.graphql.model.types;
    exports org.apache.isis.viewer.graphql.model.toplevel;
    exports org.apache.isis.viewer.graphql.model.registry;
    exports org.apache.isis.viewer.graphql.model.domain;
    exports org.apache.isis.viewer.graphql.model.exceptions;
    exports org.apache.isis.viewer.graphql.model.context;
    exports org.apache.isis.viewer.graphql.model.mmproviders;
    exports org.apache.isis.viewer.graphql.model.fetcher;

    requires org.apache.isis.core.config;
    requires org.apache.isis.incubator.viewer.graphql.applib;
    requires spring.context;
    requires org.apache.isis.core.metamodel;
    requires com.graphqljava;
    requires spring.boot.autoconfigure;
}
