/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.viewer.graphql.model.domain;

import static graphql.schema.GraphQLFieldDefinition.newFieldDefinition;

import java.util.Map;

import org.apache.isis.applib.annotation.Where;
import org.apache.isis.core.metamodel.consent.InteractionInitiatedBy;
import org.apache.isis.core.metamodel.object.ManagedObject;
import org.apache.isis.core.metamodel.spec.ObjectSpecification;
import org.apache.isis.core.metamodel.spec.feature.OneToOneAssociation;
import org.apache.isis.viewer.graphql.applib.types.TypeMapper;
import org.apache.isis.viewer.graphql.model.context.Context;
import org.apache.isis.viewer.graphql.model.exceptions.DisabledException;
import org.apache.isis.viewer.graphql.model.exceptions.HiddenException;
import org.apache.isis.viewer.graphql.model.exceptions.InvalidException;

import graphql.schema.DataFetchingEnvironment;
import graphql.schema.GraphQLArgument;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLOutputType;
import lombok.val;

//@Log4j2
public class GqlvMutationForProperty {

    private final Holder holder;
    private final ObjectSpecification objectSpec;
    private final OneToOneAssociation oneToOneAssociation;
    private final Context context;
    private final GraphQLFieldDefinition field;
    private String argumentName;

    public GqlvMutationForProperty(
            final Holder holder,
            final ObjectSpecification objectSpec,
            final OneToOneAssociation oneToOneAssociation,
        final Context context) {
        this.holder = holder;
        this.objectSpec = objectSpec;
        this.oneToOneAssociation = oneToOneAssociation;
        this.context = context;

        this.argumentName = context.isisConfiguration.getViewer().getGraphql().getMutation().getTargetArgName();

        GraphQLOutputType type = context.typeMapper.outputTypeFor(objectSpec);  // setter returns void, so will return target instead.
        if (type != null) {
            val fieldBuilder = newFieldDefinition()
                    .name(fieldName(objectSpec, oneToOneAssociation))
                    .type(type);
            addGqlArguments(fieldBuilder);
            this.field = holder.addField(fieldBuilder.build());
        } else {
            this.field = null;
        }
    }

    private static String fieldName(
            final ObjectSpecification objectSpecification,
            final OneToOneAssociation oneToOneAssociation) {
        return TypeNames.objectTypeNameFor(objectSpecification) + "__" + oneToOneAssociation.getId();
    }


    public void addDataFetcher() {

        val beanSort = oneToOneAssociation.getElementType().getBeanSort();

        switch (beanSort) {
            case VALUE:
            case VIEW_MODEL:
            case ENTITY:
                context.codeRegistryBuilder.dataFetcher(
                        holder.coordinatesFor(field),
                        this::set);

                break;
        }

        context.codeRegistryBuilder.dataFetcher(
                holder.coordinatesFor(field),
                this::set
        );
    }

    private Object set(final DataFetchingEnvironment dataFetchingEnvironment) {


        Object target = dataFetchingEnvironment.getArgument(argumentName);
        Object sourcePojo = GqlvAction.asPojo(objectSpec, target, context.bookmarkService)
                    .orElseThrow(); // TODO: better error handling if no such object found.

        val managedObject = ManagedObject.adaptSingular(objectSpec, sourcePojo);

        Map<String, Object> arguments = dataFetchingEnvironment.getArguments();
        Object argumentValue = arguments.get(oneToOneAssociation.getId());
        ManagedObject argumentManagedObject = ManagedObject.adaptProperty(oneToOneAssociation, argumentValue);

        val visibleConsent = oneToOneAssociation.isVisible(managedObject, InteractionInitiatedBy.USER, Where.ANYWHERE);
        if (visibleConsent.isVetoed()) {
            throw new HiddenException(oneToOneAssociation.getFeatureIdentifier());
        }

        val usableConsent = oneToOneAssociation.isUsable(managedObject, InteractionInitiatedBy.USER, Where.ANYWHERE);
        if (usableConsent.isVetoed()) {
            throw new DisabledException(oneToOneAssociation.getFeatureIdentifier());
        }

        val validityConsent = oneToOneAssociation.isAssociationValid(managedObject, argumentManagedObject, InteractionInitiatedBy.USER);
        if (validityConsent.isVetoed()) {
            throw new InvalidException(validityConsent);
        }

        oneToOneAssociation.set(managedObject, argumentManagedObject, InteractionInitiatedBy.USER);

        return managedObject; // return the original object because setters return void
    }


    private void addGqlArguments(final GraphQLFieldDefinition.Builder fieldBuilder) {

        // add target
        val targetArgName = context.isisConfiguration.getViewer().getGraphql().getMutation().getTargetArgName();
        fieldBuilder.argument(
                GraphQLArgument.newArgument()
                        .name(targetArgName)
                        .type(context.typeMapper.inputTypeFor(objectSpec))
                        .build()
        );

        fieldBuilder.argument(
                GraphQLArgument.newArgument()
                        .name(oneToOneAssociation.getId())
                        .type(context.typeMapper.inputTypeFor(oneToOneAssociation, TypeMapper.InputContext.INVOKE))
                        .build());
    }


    public interface Holder
            extends GqlvHolder {
    }

}
