module org.apache.isis.incubator.viewer.graphql.model {
    exports org.apache.isis.viewer.graphql.model;
    exports org.apache.isis.viewer.graphql.model.context;
    exports org.apache.isis.viewer.graphql.model.domain;
    exports org.apache.isis.viewer.graphql.model.domain.common;
    exports org.apache.isis.viewer.graphql.model.domain.common.interactors;
    exports org.apache.isis.viewer.graphql.model.domain.common.query;
    exports org.apache.isis.viewer.graphql.model.domain.common.query.meta;
    exports org.apache.isis.viewer.graphql.model.domain.rich;
    exports org.apache.isis.viewer.graphql.model.domain.rich.query;
    exports org.apache.isis.viewer.graphql.model.domain.rich.mutation;
    exports org.apache.isis.viewer.graphql.model.domain.simple;
    exports org.apache.isis.viewer.graphql.model.domain.simple.query;
    exports org.apache.isis.viewer.graphql.model.domain.simple.mutation;
    exports org.apache.isis.viewer.graphql.model.exceptions;
    exports org.apache.isis.viewer.graphql.model.fetcher;
    exports org.apache.isis.viewer.graphql.model.mmproviders;
    exports org.apache.isis.viewer.graphql.model.registry;
    exports org.apache.isis.viewer.graphql.model.toplevel;
    exports org.apache.isis.viewer.graphql.model.types;
    exports org.apache.isis.viewer.graphql.model.domain.rich.scenario;

    requires org.apache.isis.core.config;
    requires org.apache.isis.core.metamodel;
    requires org.apache.isis.incubator.viewer.graphql.applib;
    requires spring.boot.autoconfigure;
    requires spring.context;
    requires com.graphqljava;
    requires com.graphqljava.extendedscalars;
}
