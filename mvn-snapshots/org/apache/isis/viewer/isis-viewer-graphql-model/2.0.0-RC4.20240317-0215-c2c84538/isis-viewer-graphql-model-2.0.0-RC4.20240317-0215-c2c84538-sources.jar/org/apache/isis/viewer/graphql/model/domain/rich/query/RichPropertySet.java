/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.viewer.graphql.model.domain.rich.query;

import java.util.Map;

import graphql.schema.DataFetchingEnvironment;

import static graphql.schema.GraphQLFieldDefinition.newFieldDefinition;

import org.apache.isis.applib.annotation.Where;
import org.apache.isis.core.metamodel.consent.InteractionInitiatedBy;
import org.apache.isis.core.metamodel.object.ManagedObject;
import org.apache.isis.viewer.graphql.model.context.Context;
import org.apache.isis.viewer.graphql.model.domain.Element;
import org.apache.isis.viewer.graphql.model.domain.SchemaType;
import org.apache.isis.viewer.graphql.model.domain.common.interactors.PropertyInteractor;
import org.apache.isis.viewer.graphql.model.exceptions.DisabledException;
import org.apache.isis.viewer.graphql.model.exceptions.HiddenException;
import org.apache.isis.viewer.graphql.model.exceptions.InvalidException;
import org.apache.isis.viewer.graphql.model.fetcher.BookmarkedPojo;
import org.apache.isis.viewer.graphql.model.types.TypeMapper;

import lombok.val;

public class RichPropertySet extends Element {

    final PropertyInteractor propertyInteractor;

    public RichPropertySet(
            final PropertyInteractor propertyInteractor,
            final Context context) {
        super(context);
        this.propertyInteractor = propertyInteractor;

        // setters return void, so we return the domain object instead
        val graphQLOutputType = this.context.typeMapper.outputTypeFor(propertyInteractor.getObjectSpecification(), SchemaType.RICH);

        val fieldBuilder = newFieldDefinition()
                .name("set")
                .type(graphQLOutputType);
        propertyInteractor.addGqlArgument(propertyInteractor.getObjectMember(), fieldBuilder, TypeMapper.InputContext.INVOKE);
        setField(fieldBuilder.build());
    }

    @Override
    protected Object fetchData(final DataFetchingEnvironment dataFetchingEnvironment) {

        val sourcePojo = BookmarkedPojo.sourceFrom(dataFetchingEnvironment);

        val sourcePojoClass = sourcePojo.getClass();
        val objectSpecification = context.specificationLoader.loadSpecification(sourcePojoClass);
        if (objectSpecification == null) {
            return null;
        }

        val otoa = propertyInteractor.getObjectMember();
        val managedObject = ManagedObject.adaptSingular(objectSpecification, sourcePojo);

        Map<String, Object> arguments = dataFetchingEnvironment.getArguments();
        Object argumentValue = arguments.get(otoa.asciiId());
        ManagedObject argumentManagedObject = ManagedObject.adaptProperty(otoa, argumentValue);

        val visibleConsent = otoa.isVisible(managedObject, InteractionInitiatedBy.USER, Where.ANYWHERE);
        if (visibleConsent.isVetoed()) {
            throw new HiddenException(otoa.getFeatureIdentifier());
        }

        val usableConsent = otoa.isUsable(managedObject, InteractionInitiatedBy.USER, Where.ANYWHERE);
        if (usableConsent.isVetoed()) {
            throw new DisabledException(otoa.getFeatureIdentifier());
        }

        val validityConsent = otoa.isAssociationValid(managedObject, argumentManagedObject, InteractionInitiatedBy.USER);
        if (validityConsent.isVetoed()) {
            throw new InvalidException(validityConsent);
        }

        otoa.set(managedObject, argumentManagedObject, InteractionInitiatedBy.USER);

        return managedObject; // return the original object because setters return void
    }

}
