/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.applib.services.marshal;

import java.util.EnumSet;

import org.springframework.lang.Nullable;

import org.apache.isis.applib.value.NamedWithMimeType.CommonMimeType;
import org.apache.isis.commons.functional.Try;

import lombok.NonNull;

/**
 * Supports marshaling and unmarshaling of the generic type T
 * for a set of mime types.
 *
 * @since 2.0 {@index}
 */
public interface MarshallerService<T> {

    Class<T> supportedClass();

    /**
     * Supported format(s) for {@link #unmarshal(String, CommonMimeType)}
     * and {@link #marshal(Object, CommonMimeType)}.
     */
    EnumSet<CommonMimeType> supportedFormats();

    /**
     * @throws UnsupportedOperationException when format is not supported
     */
    String marshal(@NonNull T value, @NonNull CommonMimeType format);

    /**
     * Returns a new de-serialized instance wrapped in a {@link Try}.
     * @throws UnsupportedOperationException when format is not supported (not wrapped)
     */
    Try<T> unmarshal(@Nullable String content, @NonNull CommonMimeType format);

}
