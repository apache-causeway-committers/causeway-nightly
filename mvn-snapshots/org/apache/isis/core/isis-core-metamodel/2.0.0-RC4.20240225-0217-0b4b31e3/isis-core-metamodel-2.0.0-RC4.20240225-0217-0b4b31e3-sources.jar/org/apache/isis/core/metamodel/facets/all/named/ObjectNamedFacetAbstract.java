/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.isis.core.metamodel.facets.all.named;

import org.apache.isis.core.metamodel.facetapi.FacetHolder;
import org.apache.isis.core.metamodel.facets.all.i8n.noun.HasNounFacetAbstract;
import org.apache.isis.core.metamodel.facets.all.i8n.noun.Noun;

/**
 * The base for the {@link ObjectNamedFacet}.
 * @since 2.0
 */
public class ObjectNamedFacetAbstract
extends HasNounFacetAbstract
implements ObjectNamedFacet {

    public static final Class<ObjectNamedFacet> type() {
        return ObjectNamedFacet.class;
    }

    protected ObjectNamedFacetAbstract(
            final Noun noun,
            final FacetHolder holder) {
        this(
                noun,
                holder,
                Precedence.DEFAULT);
    }

    protected ObjectNamedFacetAbstract(
            final Noun noun,
            final FacetHolder holder,
            final Precedence precedence) {
        super(type(),
                holder.getTranslationContext(),
                noun,
                holder,
                precedence);
    }

}
